import java.util.*;
import java.io.*;

interface operation2{
 public void area();
 public void volume();
 double pi=3.142;
}

class circle implements operation2{
  public double radius;
  double pi=3.142;
  public circle(){}
  public circle(double radius){
  this.radius=radius;
  }

  public void area(){
  System.out.println("Area of circle : "+pi*(radius*radius));
 }


  public void volume(){
  System.out.println("there is no volume of circle");
  }
}


class cylinder implements operation2{
  public double radius;
  public double height;
  double pi=3.142;
  public cylinder(){}
  public cylinder(double radius,double height){
  this.radius=radius;
  this.height=height;
  }
  

  public void area(){
  System.out.println("Area of cylinder : "+2*pi*radius*height);
  }
 
  public void volume(){
  System.out.println("volume of cylinder : "+pi*(radius*radius)*height);
  }
}

 class operation{
 public static void main(String args[]){
  Scanner sc= new Scanner(System.in);
  System.out.println("Enter radiius ");
  double r=sc.nextInt();
  System.out.println("Enter height ");
  double h=sc.nextInt();
  circle c=new circle(r);
  c.area();
  c.volume();

  cylinder cl=new cylinder(r,h);
  cl.area();
  cl.volume();
 
 } 
}













