import java.io.*;
import java.util.*;
class employee{
 private int id;
 double salary;
 String name;
 double total;
 public employee(){
  id=0;
  salary=0.0;
  name=""; 
 }
 public employee(int id,String name,double salary){
  this.id=id;
  this.name=name;
  this.salary=salary;
 }
 public void accept()throws IOException{
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter employee id :");
  id=sc.nextInt();

  System.out.println("Enter employee name :");
  name=sc.next();

  System.out.println("Enter employee salary :");
  salary=sc.nextDouble();
 }
 public double total(){
  total=total+salary;
   return total;
 }
 public void display(){
  System.out.println("Employee id : "+id);
  System.out.println("Employee name : "+name);
  System.out.println("Employee salary :"+salary);
 }
}

class Manager extends employee{
 private double bonus;
 public void accept()throws IOException{
  super.accept();
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter bonus of the employee :");
  bonus=sc.nextDouble();
  super.total=bonus;
}

public void display(){
 super.display();
 System.out.println("Employee bonus is : "+bonus);
 System.out.println("Employee total salary is : "+total);
 }
}

public class sa11{
 public static void main(String args[])throws IOException{
  Manager m[]=new Manager[10];
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter the number of employees:");
  int n=sc.nextInt();
  for(int i=0;i<n;i++){
   m[i]=new Manager();
   m[i].accept();
   m[i].total();
  }
  for(int i=0;i<n;i++){
   m[i].display();
   System.out.println("******************************************************");
  }
  double src=m[0].total;
  int temp=0;
  for(int i=1;i<n;i++){
   if(src<m[i].total){
    src=m[i].total;
    temp=i;
   }
  }
  System.out.println("The Employee having maximum total salary is :");
  m[temp].display();
 }
}

