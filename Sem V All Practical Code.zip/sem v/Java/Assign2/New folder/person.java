import java.io.*;
import java.util.*;
import utility.*;

public class person{
 public static String name;
 public static String city;
 

 public static void main(String args[])throws IOException{
    CapitalString ct=new CapitalString();
    Scanner sc= new Scanner(System.in);
    System.out.println("Enter  name : ");
    name=sc.nextLine();
    System.out.println("Enter  city : ");
    city=sc.nextLine();
    ct.convert(name,city);
  }
}
