package series;

public class series{
 public void fibonacci(int n){
  int first=0,second=1,next;
  System.out.println("Fibonacci series : ");
  for(int i=0;i<=n;i++){
   if(i<=1)
   next=i;
   else{
    next=first+second;
    first=second;
    second=next;
   }
   System.out.println(next);
  }
 }
 public void cube(int n){
  System.out.println("cube of the number is"+(n*n*n));
 }
  public void square(int n){
  System.out.println("square of the number is"+(n*n));
 }
}
