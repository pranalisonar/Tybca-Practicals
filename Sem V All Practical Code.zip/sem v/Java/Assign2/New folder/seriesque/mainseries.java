import series.*;
import java.io.*;
import java.util.*;

public class mainseries{
 public static void main(String args[])throws IOException{
  series s=new series();
  Scanner sc=new Scanner(System.in);
  int i;
  do{
    System.out.println("Enter a number/ 0 to exit ");
    i=sc.nextInt();
    s.fibonacci(i);
    s.cube(i);
    s.square(i);
   }while(i>0);
 }
}
