import java.io.*;
import java.util.*;
public class point
{
 public int x;
 public int y;

 public point()
 {
  x=10;
  y=20;
 }
 public point(int x,int y)
 {
   this.x=x;
   this.y=y;
 }
public static void main(String[]args)
  {
   colorpoint ob=new colorpoint();
   ob.display();
   point3D ob2=new point3D();
   ob2.display();
  }
 }
class colorpoint extends point
 {
  public String color="Blue";
  public void display()
 {
  System.out.println("colorpoint Details:");
  System.out.println("x coordinate:"+x);
  System.out.println("y coordinate:"+y);
  System.out.println("color:"+color);
  System.out.println("\n_________________________\n");
 }
}
class point3D extends point
 {
  public int z=30;
  public void display()
  {
   System.out.println("colorpoint Details:");
   System.out.println("x coordinate:"+x);
   System.out.println("y coordinate:"+y);
   System.out.println("z coordinate:"+z);
  }
 }

