package utility;
import java.util.*;
import java.io.*;
public class CapitalString
{
   public void cap(String name)
   {
     name=name.substring(0,1).toUpperCase()+name.substring(1);
     System.out.println("\nThe name is:"+name);
   }
  // public static void main(String args[]) throws IOexception	
//   {
////    
//   }
}
