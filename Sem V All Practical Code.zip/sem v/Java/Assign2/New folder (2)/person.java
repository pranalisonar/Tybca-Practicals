import java.io.*;
import java.util.*;

import utility.*;

public class person
{
	public static void main(String args[])
  	{
		Scanner sc=new Scanner(System.in);
                String n;
                String city;
		System.out.println("\nEnter the name:");
		n=sc.nextLine();
		System.out.println("\nEnter the city:");
		city=sc.nextLine();
		CapitalString cp=new CapitalString();
		cp.cap(n);
		System.out.println("\nThe city is:"+city);
	}
}
