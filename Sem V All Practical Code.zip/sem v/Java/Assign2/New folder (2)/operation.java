import java.io.*;
import java.util.*;

interface Operation2
{
  public double pie=3.142;
  public void area();
  public void volume();
}
class circle implements Operation2
{
   double radius=2;
   public void area()
   {
      double resultarea;
      resultarea=pie*radius*radius;
      System.out.println("\nThe area of circle is:"+resultarea);
   }
   public void volume()
   {
   }
}
class cylinder implements Operation2
{
   double radius=3;
   double height=4;
   public void area()
   {
     double resultArea;
      resultArea=2*pie*radius*height+2*pie*radius*radius;
      System.out.println("\nThe area of cylinder is:"+resultArea);
   }
   public void volume()
   {
     double resultvol;
     resultvol=pie*radius*radius*height;
     System.out.println("\nThe Volume of cylinder is:"+resultvol);
   }
}
class operation
{
  public static void main(String args[])
  {
     circle c=new circle();
     c.area();
     c.volume();
     cylinder c1=new cylinder();
     c1.area();
     c1.volume();
  }
}
