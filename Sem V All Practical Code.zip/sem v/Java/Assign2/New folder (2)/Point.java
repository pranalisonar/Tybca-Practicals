import java.io.*;
import java.util.*;
class Point
{
   public int x;
   public int y;
 
  public Point()
  {
     x=10;
     y=20;
  }
  public Point(int x,int y)
  {
    this.x=x;
    this.y=y;
  }
  public static void main(String args[])
	{
		ColorPoint ob=new ColorPoint();
		ob.display();
		
		Point3D ob2 = new Point3D();
		ob2.display();
	
	}
  void display()
  {
    System.out.println("X and Y"+x+ " & "+y);
  }
}
  class ColorPoint extends Point
  {
    public String color="Blue";
    public void display()
    {
     System.out.println("ColorPoint details:");
     System.out.println("X coordinate:"+x);
     System.out.println("Y coordinate:"+y);
     System.out.println("Color:"+color);
     System.out.println("\n_______________________________\n");
    }
  }
    
class Point3D extends Point
{
	public int z=30;
	public void display()
        {
	  System.out.println("ColorPoint details:");
          System.out.println("X coordinate:"+x);
          System.out.println("Y coordinate:"+y);
          System.out.println("Z coordinates:"+z);
     
    }
	
}
	

