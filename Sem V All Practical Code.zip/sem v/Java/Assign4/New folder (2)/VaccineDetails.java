import java.awt.*;
import javax.swing.*;

class VaccineDetails extends JFrame
{
  JFrame frame = new JFrame();
  VaccineDetails()
  {
    frame.setLayout(new FlowLayout());
    
    JLabel l1 = new JLabel("  Vaccination Details               ",JLabel.CENTER);
    JLabel l2 = new JLabel("Name:");
    JLabel l3 = new JLabel("Dose ",JLabel.LEFT);
    JLabel l4 = new JLabel("Vaccine ",JLabel.RIGHT);
    JTextField t1 = new JTextField(40);
    JCheckBox cb1 = new JCheckBox("1st Dose",false);
    JCheckBox cb2 = new JCheckBox("2nd Dose",false);
    JRadioButton rb1 = new JRadioButton("Covishield",false);
    JRadioButton rb2 = new JRadioButton("Covaxin",false);
    JRadioButton rb3 = new JRadioButton("Sputnik V",false);
    JTextArea t2 = new JTextArea("Name:______________________________ 1st Dose:_________ 2nd:________\nVaccine:________________",2,1);
   
    JPanel p1 = new JPanel();
    JPanel p2 = new JPanel();
    p2.setLayout(new GridLayout(3,1,250,2));
    JPanel p3 = new JPanel();
    p3.setLayout(new GridLayout(4,1,250,2));
    JPanel p4 = new JPanel();
    JPanel p5 = new JPanel();
    p1.add(l1);
    p5.add(l2);
    p5.add(t1);
    p2.add(l3);
    p2.add(cb1);
    p2.add(cb2);
    p3.add(l4);
    p3.add(rb1);
    p3.add(rb2);
    p3.add(rb3);
    p4.add(t2);
    
    frame.add(p1);
    frame.add(p5); 
    frame.add(p2);
    frame.add(p3);
    frame.add(p4);
        
    frame.setSize(500,300);
    frame.setVisible(true);
  }  
  
  public static void main(String args[])
  {
    VaccineDetails vd = new VaccineDetails();
  }
  
}
