import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.lang.*; 
public class a22 extends JFrame
{ JFrame f1;
  a22()
 {
   f1=new JFrame("Vaccination Details");
   JPanel p1=new JPanel();
   JPanel p2=new JPanel();
   JPanel p3=new JPanel();
   JLabel l1=new JLabel("Vaccination Details",JLabel.CENTER);
   System.out.println("\n\n");
   JLabel l2=new JLabel("Name:",JLabel.CENTER);
   l2.setBounds(120,50,200,50);
   JTextField j1=new JTextField(25);
   JLabel l3=new JLabel();
   l2.setBounds(120,50,200,50);
    System.out.println("\n\n");
   l3.setText("Dose");
   JCheckBox c1=new JCheckBox("1st Dose",false);
   JCheckBox c2=new JCheckBox("2nd Dose",false); 
   JLabel l4=new JLabel();
   l4.setText("Vaccine");
   JRadioButton r1=new JRadioButton("Covishield");
   JRadioButton r2=new JRadioButton("Covaxin"); 
   JRadioButton r3=new JRadioButton("Sputnik V");
   setLayout(new BorderLayout());
   add(p1,BorderLayout.NORTH);
   p1.add(l1);
   p1.add(l2);
   p1.add(j1);
   p1.add(l3);
   p1.add(c1);
   p1.add(c2);
   p1.add(l4);
   p1.add(r1);
   p1.add(r2);
   p1.add(r3);
   f1.setSize(300,300);
   f1.setVisible(true);
   f1.add(p1);
   f1.show();
}
  public static void main(String[] args)throws Exception
   {
     new a22();
   }
}
