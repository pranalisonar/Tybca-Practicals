import javax.swing.*;
import java.awt.*;
public class sa2 extends JFrame{
JTextField name,jt;
JLabel l1,l2,dose,vaccine;
JCheckBox c1,c2;
JRadioButton r1,r2,r3;
JButton b1,b2;

 sa3(){
