import java.awt.event.*;
import javax.swing.*;
public class sa4{
 JFrame f;
 sa4(){
 f=new JFrame("Combobox Example");
 JLabel label=new JLabel();
 label.setHorizontalAlignment(JLabel.CENTER);
 label.setSize(400,100);
 JButton b=new JButton("Show");
 b.setBounds(200,100,75,20);
 String languages[]={"C","C++","Java","Php","Web-Dev"};
 JComboBox jc=new JComboBox(languages);
 jc.setBounds(50,100,90,20);
 f.add(jc);
 f.add(label);
 f.add(b);
 f.setLayout(null);
 f.setSize(350,350);
 f.setVisible(true);
 b.addActionListener(new ActionListener(){
   public void actionPerformed(ActionEvent e){
    String data="Programing Language Selected :"+jc.getItemAt(jc.getSelectedIndex());
    label.setText(data);
    }
  });
}
public static void main(String args[]){
    new sa4();
  }
}
