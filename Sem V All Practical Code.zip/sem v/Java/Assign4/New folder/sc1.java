import javax.swing.*;
import java.awt.*;
public class sc1 extends JFrame{

