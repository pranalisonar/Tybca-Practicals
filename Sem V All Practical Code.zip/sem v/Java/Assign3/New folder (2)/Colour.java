import java.util.*;
class Colour
{
  public static void main(String[] args)
  {
     LinkedList l=new LinkedList();
     l.add("Red");
	 l.add("Blue");
      l.add("Yellow");
      l.add("Orange");
     Iterator i=l.iterator();
     System.out.println("\ncontents of the List using an Iterator");
     while(i.hasNext())
     {
         String s=(String)i.next();
          System.out.println(s);
      }
    ListIterator li=l.listIterator();
    while(li.hasNext())
    {
       li.next();
    }
    System.out.println("\ncontents of the List in reverse order using a ListItertor");
    while(li.hasPrevious())
    {
       System.out.println(li.previous());
    }
    l.add(2,"Pink");
    l.add(3,"Green");
    System.out.println("\nlist between blue and yellow is:");
    System.out.println(l);
  }

}
