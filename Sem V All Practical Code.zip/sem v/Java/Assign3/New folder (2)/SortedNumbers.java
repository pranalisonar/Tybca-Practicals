import java.util.*;
import java.io.*;
class SortedNumbers
{
  public static void main(String[] args)throws Exception
  {
     BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
     Set s=new TreeSet();
     System.out.print("Enter no.of integers:");
     int n=Integer.parseInt(br.readLine());
     for(int i=0;i<n;i++)
     {
       System.out.print("Enter no.:");
       int x=Integer.parseInt(br.readLine());
       s.add(x);
     }
     Iterator itr=s.iterator();
     while(itr.hasNext())
     {
         System.out.print(itr.next());
     }
  System.out.print("\nEnter element to be searched:\t");
   int no=Integer.parseInt(br.readLine());

  if(s.contains(no))
       System.out.print("Number" +no+ "Found");
  else
       System.out.print("Number" +no+ " not Found");
  }
 }
