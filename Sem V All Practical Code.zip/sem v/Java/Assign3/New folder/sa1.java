import java.util.*;
import java.io.*;

class sa1{

    public static void main(String args[])throws IOException{
     Scanner sc=new Scanner(System.in);
     Set s =new TreeSet();

     System.out.println("Enter no of elements : ");
     int n=sc.nextInt();

     for(int i=0;i<n;i++){
     System.out.println("Enter numbers : ");
     int x=sc.nextInt();
     s.add(x);
    }
    System.out.println(); 
    Iterator itr=s.iterator();
    while (itr.hasNext()){
    System.out.println(itr.next());
    }
    System.out.println("\n\nEnter the number to be searched :");
    int no=sc.nextInt();
    
    if(s.contains(no))
    System.out.println("number "+no+" found .");
    else
    System.out.println("number "+no+" not found .");
  }
} 
