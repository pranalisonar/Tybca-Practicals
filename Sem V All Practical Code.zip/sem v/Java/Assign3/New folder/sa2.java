import java.util.*;
import java.io.*;

class sa2{

    public static void main(String args[])throws IOException{
     Scanner sc=new Scanner(System.in);
     Hashtable ht =new Hashtable();
     
     String name=null;
     float sal;
     
     System.out.println("Enter no of Employess : ");
     int n=sc.nextInt();

     for(int i=0;i<n;i++){
     System.out.println("Enter employee name : ");
     name=sc.next();
     System.out.println("Enter employee salary : ");
     sal=sc.nextFloat();
     ht.put(name,sal);
    }
    System.out.println("Hash Table ="+ht); 
    Enumeration k=ht.keys();
    Enumeration v=ht.elements();
    System.out.println("Name\tSalary");
    while(k.hasMoreElements()){
    System.out.println(k.nextElement()+"\t"+v.nextElement());
    }
    System.out.println("\n\nEnter Name of the employee to be searched :");
    String st=sc.next();
    k=ht.keys();
    v=ht.elements();
    int cnt=0;
     
    while(k.hasMoreElements()){
     name=(String)k.nextElement();
    if(st.equals(name)){
    cnt++;
    System.out.println("Salary = "+v.nextElement());
  }
}   
    if(cnt==0) 
    System.out.println("Employee not found .");
  } 
}
