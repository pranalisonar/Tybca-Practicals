import java.io.*;
import java.util.Scanner;
public class aq2
{
 public static void main(String args[]) throws IOException
  {
   int n,r=0,a=0;
   //Scanner obj = new Scanner(System.in);
   n= Integer.parseInt(args[0]);
   System.out.print("Enter no : ");
   //int n=obj.nextInt();
   while(n!=0)
   {
    a = n % 10;
    r = r * 10 + a;
    n =n / 10;
   }
   System.out.println("Reverse No : "+r);
  }
}
