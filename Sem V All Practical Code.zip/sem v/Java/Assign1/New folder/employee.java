import java.io.*;
import java.util.*;
public class employee{
	String name;
	float salary;
	public void getdata(){
	 Scanner sc=new Scanner(System.in);
	System.out.println("Enter employee name ");	 
	name=sc.next();
	System.out.println("Enter employee Salary ");	 
	salary=sc.nextFloat();
	}
	public void display(){
	System.out.println("Emloyee name is : "+name);
	System.out.println("Emloyee salary is : "+salary);
	}
	public static void main(String args[]){
	employee e[]=new employee[5];
	for(int i=0;i<5;i++){
	e[i]=new employee();
	e[i].getdata();
	}
	System.out.println("***Data Entered as Below");
	for(int i=0;i<5;i++){
	e[i].display();
	}
    }
}
