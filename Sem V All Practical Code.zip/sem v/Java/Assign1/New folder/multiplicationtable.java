import java.io.*;
import java.util.*;
public class multiplicationtable{
	public static void main(String args[])throws IOException{
	int num;
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter a number for multipliaction table");
	 num	=Integer.parseInt(br.readLine());
	System.out.println("****MULTIPLICATION TABLE****");
	for(int i=1;i<=10;i++){
	System.out.println(num+"x"+i+"="+num*i);        
	}
			
    }

}
