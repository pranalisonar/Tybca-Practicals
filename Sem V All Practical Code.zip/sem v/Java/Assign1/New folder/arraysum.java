import java.io.*;
import java.util.*;

public class arraysum{
	public static void arrsum(int arr[]){
	int sum=0;
	for(int i=0;i<arr.length;i++){
	   sum=sum+arr[i];	
	     }
	   System.out.println("sum of the array elements is  "+sum);
	}
	public static void sortarr(int arr[]){
	for(int j=0;j<arr.length;j++){
		if(arr[j]>arr[j+1]){
		   int temp=arr[j+1];
		   arr[j+1]=arr[j];
		   arr[j]=temp;		
		}	
 	    }
	System.out.println("Elements after sorted in asscending order");
	for(int j=0;j<arr.length;j++){
	   System.out.println(arr[j]+ " ");
		}
	}
	public static void main(String args[]){
	int arr[]={10,30,20,50,40,90,70};
	arrsum(arr);
	sortarr(arr);
    }
}
