import java.io.*;
import java.util.*;

public class arrsum222{
	public static void main(String args[]){
	int arr[]={10,30,20,50,40,90,70};
	int sum=0;
	for(int i=0;i<arr.length;i++){
	   sum=sum+arr[i];	
	     }
	   System.out.println("sum of the array elements is :: "+sum);
	int temp=0;
	for(int i=0;i<arr.length;i++){
	for(int j=i+1;j<arr.length;j++){
		if(arr[i]>arr[j]){
		   temp=arr[i];
		   arr[i]=arr[j];
		   arr[j]=temp;		
		}	
 	    }
}
	System.out.println("Elements after sorted in asscending order");
	for(int i=0;i<arr.length;i++){
	   System.out.print(arr[i]+ " ");
    }
}
}
