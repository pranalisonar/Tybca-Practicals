import java.io.*;

public class MyDate{
	private int dd;
	private int mm;
	private int yy;
	public MyDate(){}
	public MyDate(int dd,int mm,int yy ){
	   this.dd=dd;
	   this.mm=mm;
	   this.yy=yy;
	}
	public void display(){
	   System.out.println("Date is :: "+dd+"-"+mm+"-"+yy);
	}
	public static void main(String args[])throws IOException{
	MyDate m1=new MyDate();
	MyDate m2=new MyDate(27,02,2002);
	m2.display();
    }
}
