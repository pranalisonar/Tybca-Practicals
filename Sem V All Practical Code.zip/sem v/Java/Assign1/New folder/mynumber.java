import java.io.*;
import java.util.*;
public class mynumber{
	public int a;
	public mynumber(){
	  a=0;
	}
	public mynumber(int a){
	  this.a=a;
	}
	public boolean isNegetive(){
	if(a<0)
	    return true;
	    else return false;	
	}
	
	public boolean isPositive(){
	if(a>0)
	    return true;
	    else return false;	
	}

	public boolean isEven(){
	if(a%2==0)
	    return true;
	    else return false;	

	}

	public boolean isOdd(){
	if(a%2!=0)
	    return true;
	    else return false;	
	}
	public static void main(String args[])throws IOException{
	System.out.println("Enter a number");
	int num=Integer.parseInt(args[0]);
	mynumber m=new mynumber(num);
	if(m.isNegetive())
	System.out.println("Number is negetive");
	if(m.isPositive())
	System.out.println("Number is Positive");
	if(m.isEven())
	System.out.println("Number is Even");
	if(m.isOdd())
	System.out.println("Number is Odd");	
    }
}















