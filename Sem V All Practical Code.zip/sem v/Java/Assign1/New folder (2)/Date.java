import java.io.*;
import java.util.*;
class date
{
 public int dd;
 public int mm;
 public int yy;
 
 public date()
 {}
 public date (int dd,int mm,int yy)
 {
  this.dd=dd;
  this.mm=mm;
  this.yy=yy;

 }
 public void display()
 {
  System.out.println("date is:"+dd+"-"+mm+"-"+yy);
 }
  public static void main(String args[])throws IOException
 { 
  date d1=new date();
  date d2=new date(18,07,2002);
  d2.display();
 }
}
