import java.io.*;
import java.util.*;
public class Employee
{
 public String name;
 public double salary;

 Scanner sc=new Scanner(System.in);
 public void getdata()
 {
   System.out.println("Enter name:");
   name=sc.next();
 
   System.out.println("Enter salary:");
   salary=sc.nextDouble();
 }
 public void display() 
 {
   System.out.println("Name is:"+name);
   System.out.println("Salary is:"+salary);
 }
 public static void main(String args[])
 {
   Employee e1[]=new Employee[5];
   for(int i=0;i<e1.length;i++)
   {
     e1[i]=new Employee();
     e1[i].getdata();
    // e1[i].display();
   }
  for(int i=0;i<e1.length;i++)
  {
      e1[i].display();
  }
  }
}
