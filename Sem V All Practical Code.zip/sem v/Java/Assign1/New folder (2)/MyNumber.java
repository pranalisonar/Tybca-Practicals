import java.io.*;

public class MyNumber
{
 public int a;
 public MyNumber()
 {
  a=0;
 }
 public MyNumber(int a)
 {
  this.a=a;
 }
 public void isNegative()
 {
  if(a<0)
   System.out.println("Number is Negative");
   
 }
  public void isPositive()
 {
  if(a>0)
   System.out.println("Number is Positive"); 
 }
 public void isOdd()
 {
  if(a%2!=0)
   System.out.println("Number is odd");
 }
 public void isEven()
 {
  if(a%2==0)
     System.out.println("Number is even");
 }
 public static void main(String args[])
 {
  int a=Integer.parseInt(args[0]);
  MyNumber m=new MyNumber(a);
  
  m.isNegative();
  m.isPositive();
  m.isOdd();
  m.isEven();
   
 }
}
