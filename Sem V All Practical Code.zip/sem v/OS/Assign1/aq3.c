#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
main()
{
    int pid;
    pid = fork();
    if (pid == 0)
    {
        printf("Child process is running\n ");
        execl("/bin/ls", "ls", NULL);
    }
    else
    {
        printf("Child Process is terminated\n");
        sleep(2);
    }
    return 0;
}
