list1=["abhi","pinak","sandy_24"]
print(list1)
list1.append("yash")
print(list1)
del(list1[1])
print(list1)

