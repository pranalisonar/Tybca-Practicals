string1='hello'
string2='world'
print string1,string2
print'string1[0]=',string1[0]
print'string1[-1]=',string1[-1]
print string1
print 'str[1:4]=',string1[1:4]
print 'Updated string=',string1 +'python'
