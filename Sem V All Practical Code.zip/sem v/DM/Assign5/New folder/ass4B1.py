{
    "nbformat":4,
    "nbformat_minor":0,
    "metadata":{
        "colab":{
            "name":"Data Mining Assignment 3 Set",
            "provenance":[]
        },
            "kernelspec":{
                "name":"python 3",
                "display_name":"Python 3"
        },
        "language_info":{
            "name":"python"
        
        
        }
        },
        "cells":[
            {
                "cell_type":"markdown",
                "source":["### set-b\n","\n"]
                
            }
        
